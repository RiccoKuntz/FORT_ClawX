# 💾 Guardian - Backup-Struktur Prüfbericht
**Zeitstempel:** Di 21. Apr 05:14:19 CEST 2026

## Backup-Ziel-Pfad
/mnt/83a625d2-74c8-463d-bb27-bb094f5ad15d/Backup/OpenClaw/GARVIS/

## Verfügbare Backup-Ordner:
- ✅ Ordner existiert
insgesamt 0
drwxrwxr-x 1 rick rick  34 Apr 21 05:01 .
drwxrwxr-x 1 rick rick 118 Apr 20 16:13 ..
drwxrwxr-x 1 rick rick  26 Apr 21 05:03 AUTOMATION Repair
