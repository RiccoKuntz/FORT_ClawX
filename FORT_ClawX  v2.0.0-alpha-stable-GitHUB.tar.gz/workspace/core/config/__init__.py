# -*- coding: utf-8 -*-
"""
TUI Core – Asynchronous Status Monitoring System
==============================================

Hardware Context: Lenovo ThinkPad T400
- CPU: Intel Core2 Duo P8400 @ 2.26GHz (1C2T)
- RAM: 8GB DDR3 1066MHz Dual Channel
- SSD: Intenso SSD

This system provides non-blocking status monitoring for OpenClaw agents,
optimized for the T400's hardware constraints.

"""

# Version & Metadata
__version__ = "0.1.0"
__author__ = "OpenClaw Team"
__license__ = "MIT"

from .tui_core_config import (
    STATUS_BUFFER, 
    update_status, 
    get_status,
    check_thermal,
    ThreadPriorities
)

from .input_listener import InputListener, start_input_listener

from .agent_executor import AgentExecutor, MultiAgentExecutor

from .status_monitor import StatusMonitor


__all__ = [
    "STATUS_BUFFER",
    "update_status", 
    "get_status",
    "check_thermal",
    "ThreadPriorities",
    "InputListener",
    "start_input_listener",
    "AgentExecutor",
    "MultiAgentExecutor",
    "StatusMonitor"
]


def main():
    """Main entrypoint for TUI Core."""
    from .status_monitor import StatusMonitor
    
    monitor = StatusMonitor(
        agent_name="OpenClaw_TUI_Core",
        interval=2.0,
        enable_thermal=True
    )
    monitor.run()


if __name__ == "__main__":
    main()
