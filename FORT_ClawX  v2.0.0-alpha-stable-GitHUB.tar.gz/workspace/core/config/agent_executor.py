# -*- coding: utf-8 -*-
"""
Agent Executor – Background Process Manager

Manages agent subprocesses with non-blocking execution on T400.
Uses nice -n 10 for background priority (CPU-saving on Core2 Duo).
"""

import os
import sys
import subprocess
import signal
import threading
from datetime import datetime
from tui_core_config import (
    STATUS_BUFFER, 
    BUFFER_LOCK, 
    update_status, 
    get_status,
    ThreadPriorities
)


# ============================================================
# AGENT PROCESS CLASS
# ============================================================

class AgentExecutor:
    """
    Manages agent subprocesses with proper lifecycle handling.
    
    T400 Optimized:
    - Background priority: nice -n 10 (low CPU usage)
    - Non-blocking execution via threading
    - Automatic cleanup on termination
    """
    
    def __init__(self, agent_name, target_function=None):
        self.agent_name = agent_name
        self.target_function = target_function if target_function is not None else None
        self.process = None
        self.pid = None
        self.running = False
        
        # Register this agent with status buffer
        update_status(self.agent_name, "Initialized", f"Agent Executor ready (nice={ThreadPriorities.BACKGROUND_AGENT})")
        
    def start(self):
        """Start agent process with background priority."""
        print(f"\n🚀 Starting {self.agent_name}...")
        
        # Start subprocess as background job
        try:
            self.process = subprocess.Popen(
                sys.executable,
                args=[sys.argv[0]] if sys.argv else [],  # Pass main script
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                preexec_fn=os.setsid  # New process group for clean termination
            )
            
            self.pid = self.process.pid
            
            # Update status
            update_status(self.agent_name, "Running", f"PID={self.pid} | Background: nice -n {ThreadPriorities.BACKGROUND_AGENT}")
            
            print(f"✓ {self.agent_name} started (PID: {self.pid})")
            return True
            
        except Exception as e:
            print(f"❌ Failed to start {self.agent_name}: {e}")
            update_status(self.agent_name, "Error", f"Startup failed: {e}")
            return False
            
    def pause(self):
        """Pause agent (SIGSTOP signal)."""
        if self.process and self.pid:
            try:
                os.killpg(self.process.pid, signal.SIGSTOP)
                update_status(self.agent_name, "Paused", f"Sent SIGSTOP to PID {self.pid}")
                print(f"⏸️  {self.agent_name} paused")
            except Exception as e:
                print(f"Pause failed: {e}")
                
    def resume(self):
        """Resume agent from pause."""
        if self.process and self.pid:
            try:
                os.killpg(self.process.pid, signal.SIGCONT)
                update_status(self.agent_name, "Resumed", f"Sent SIGCONT to PID {self.pid}")
                print(f"▶️  {self.agent_name} resumed")
            except Exception as e:
                print(f"Resume failed: {e}")
                
    def terminate(self):
        """Gracefully terminate agent with SIGTERM."""
        if self.process and self.pid:
            try:
                print(f"\n⏸️  Terminating {self.agent_name} (PID: {self.pid})...")
                update_status(self.agent_name, "Stopping", f"Sent SIGTERM to PID {self.pid}")
                
                self.process.terminate()
                
                # Wait for graceful shutdown
                try:
                    self.process.wait(timeout=5)
                    print(f"✓ {self.agent_name} terminated gracefully")
                except subprocess.TimeoutExpired:
                    print("⏸️  Process didn't exit, force killing...")
                    self.process.kill()
                    
            except Exception as e:
                print(f"Termination failed: {e}")
                update_status(self.agent_name, "Error", f"Termination error: {e}")
                
    def kill(self):
        """Force kill agent immediately."""
        if self.process and self.pid:
            try:
                os.killpg(self.process.pid, signal.SIGKILL)
                print(f"💀 Force killed {self.agent_name} (PID: {self.pid})")
                update_status(self.agent_name, "Killed", f"Force SIGKILL to PID {self.pid}")
            except Exception as e:
                print(f"Force kill failed: {e}")
                
    def status(self):
        """Check if agent is still running."""
        if self.process and self.pid:
            return True if self.process.poll() is None else False
        return False


# ============================================================
# THREAD-SAFE STATUS MONITORING
# ============================================================

class MultiAgentExecutor:
    """Manages multiple agents with status tracking."""
    
    def __init__(self):
        self.agents = {}  # {agent_name: AgentExecutor}
        
    def add_agent(self, agent_name, target=None):
        """Add agent to executor pool."""
        if agent_name not in self.agents:
            self.agents[agent_name] = AgentExecutor(agent_name, target)
            
    def get_all_status(self):
        """Get status of all agents."""
        lines = []
        for name, executor in self.agents.items():
            running = executor.status() if hasattr(executor, 'status') else False
            pid = executor.pid if hasattr(executor, 'pid') and executor.pid else "N/A"
            lines.append(f"[{name}] {'✓ Running' if running else '✗ Stopped'} (PID={pid})")
        return "\n".join(lines)
        
    def terminate_all(self):
        """Terminate all agents."""
        for name, executor in self.agents.items():
            executor.terminate()


if __name__ == "__main__":
    print("=" * 60)
    print("AGENT EXECUTOR – BACKGROUND PROCESS MANAGER")
    print("=" * 60)
    
    # Create test agents
    multi = MultiAgentExecutor()
    multi.add_agent("TestAgent1", lambda: None)
    multi.add_agent("TestAgent2", lambda: None)
    
    print(f"\nRegistered Agents:\n{multi.get_all_status()}")
