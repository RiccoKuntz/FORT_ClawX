#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Status Monitor – Continuous TUI Status Output

Non-blocking status display for OpenClaw TUI.
T400 Optimized: Minimal CPU usage, thermal-aware.

Usage:
  python3 /home/rick/.openclaw/workspace/core/config/status_monitor.py [options]

Options:
  --agent=<name>     Monitor specific agent by name
  --interval=1       Update interval in seconds (default: 2)
  --thermal          Enable thermal monitoring
  --no-clear         Don't clear screen before output

Hardware Context: Lenovo T400 (Intel P8400, 8GB RAM, Core2 Duo)
"""

import os
import sys
import time
import argparse
from tui_core_config import (
    STATUS_BUFFER, 
    get_status, 
    check_thermal,
    update_status
)


# ============================================================
# THERMAL MONITOR CLASS
# ============================================================

class ThermalMonitor:
    """
    Hardware thermal monitoring for T400.
    
    Thresholds:
    - 85°C: Warning (frequency throttle initiated)
    - 95°C: Critical (forced shutdown recommendation)
    
    Location: /sys/class/thermal/thermal_zone0/temp
    """
    
    def __init__(self):
        self.thermal_file = "/sys/class/thermal/thermal_zone0/temp"
        self.warning_temp = 85.0
        self.critical_temp = 95.0
        
    def read(self):
        """Read current temperature in Celsius."""
        try:
            with open(self.thermal_file, "r") as f:
                temp_millikelvin = int(f.read().strip())
                return temp_millikelvin / 1000
        except FileNotFoundError:
            print("⚠️  Thermal sensor not found – hardware check required")
            return None
        except PermissionError:
            print("⚠️  Permission denied for thermal read (need root/sudo)")
            return None
            
    def check(self):
        """Check and return status with throttle recommendation."""
        temp = self.read()
        
        if temp is None:
            return "ERROR"
            
        status_lines = []
        
        if temp > self.critical_temp:
            status_lines.append(f"💀 CRITICAL: {temp:.1f}°C")
            status_lines.append("→ Recommendation: Power off & hardware inspection!")
            status_lines.append("→ Forced frequency throttle activated (if supported).")
            return "CRITICAL", temp, status_lines
            
        elif temp > self.warning_temp:
            status_lines.append(f"⚠️  WARNING: {temp:.1f}°C")
            status_lines.append("→ Frequency throttle will engage at this threshold.")
            update_status("ThermalMonitor", "WARNING", f"Temp={temp:.1f}°C → Throttle active")
            return "WARNING", temp, status_lines
            
        else:
            status_lines.append(f"✓ OK: {temp:.1f}°C (Safe operating range)")
            update_status("ThermalMonitor", "OK", f"Temp={temp:.1f}°C (Idle)")
            return "OK", temp, status_lines


# ============================================================
# MAIN STATUS MONITOR CLASS
# ============================================================

class StatusMonitor:
    """
    Main status monitoring loop for TUI.
    
    Non-blocking design:
    - Reads from shared STATUS_BUFFER (thread-safe)
    - Minimal CPU usage (<1% on Core2 Duo)
    - Thermal-aware throttling
    """
    
    def __init__(self, agent_name=None, interval=2, enable_thermal=True, clear_screen=True):
        self.agent_name = agent_name or "OpenClaw_TUI"
        self.interval = float(interval) if interval else 2.0
        self.enable_thermal = enable_thermal
        self.clear_screen = clear_screen
        
        # Initialize components
        self.thermal_monitor = ThermalMonitor() if enable_thermal else None
        
    def run(self):
        """Main monitoring loop – non-blocking."""
        
        update_status(self.agent_name, "Monitoring", f"Started | Interval={self.interval}s")
        print(f"\n┌─ STATUS MONITOR – {self.agent_name} ───────────────────────┐")
        print(f"├─ Hardware: Lenovo T400 (Core2 Duo P8400) 8GB RAM          │")
        print(f"├─ Status Buffer: {STATUS_BUFFER}                           │")
        print(f"└─ Monitor ID: {os.getpid()}                               │")
        print("─" * 65)
        
        try:
            while True:
                # Display current status
                status = get_status() or "Idle"
                
                # Clear screen (if enabled)
                if self.clear_screen:
                    os.system('clear')
                    print(f"\n┌─ {self.agent_name} STATUS – Continuous Monitor ───────────────┐")
                    
                print("\n┌─ CURRENT STATUS ───────────────────────────────────────────┐")
                print(f"│ Active Agent: {status[:60] if len(status) > 60 else status}")
                print("└─ Status File: " + STATUS_BUFFER + "                      │")
                
                # Thermal monitoring (if enabled)
                if self.enable_thermal and self.thermal_monitor:
                    print("\n┌─ HARDWARE THERMAL ─────────────────────────────────────────┐")
                    try:
                        status, temp, lines = self.thermal_monitor.check()
                        
                        if status == "OK":
                            print(f"│ Temperature: {temp:.1f}°C ✓ (Safe)")
                            update_status("ThermalMonitor", "OK", f"Temp={temp:.1f}°C")
                        elif status == "WARNING":
                            print(f"│ Temperature: {temp:.1f}°C ⚠️  (Throttle active)")
                            update_status("ThermalMonitor", "WARNING", f"Temp={temp:.1f}°C → Throttled")
                        else:
                            print(f"│ Temperature: {temp:.1f}°C 💀 (CRITICAL!)")
                            
                    except Exception as e:
                        print(f"│ Error reading thermal: {e}")
                        
                    print("└─ Thermal Monitor Status: " + ("Active" if self.enable_thermal else "Disabled"))
                
                # Process usage estimate (minimal)
                import psutil
                try:
                    ps = psutil.Process()
                    cpu_pct = ps.cpu_percent()
                    mem_pct = ps.memory_percent()
                    print(f"\n┌─ PROCESS USAGE ────────────────────────────────────────────┐")
                    print(f"│ CPU: {cpu_pct:.1f}% | Memory: {mem_pct:.1f}%")
                    print(f"│ PID: {ps.pid}")
                    print("└─ Process Status: Running")
                except ImportError:
                    print("\n┌─ PROCESS USAGE ────────────────────────────────────────────┐")
                    print("│ Note: psutil module not installed. CPU/Mem estimates disabled.")
                    print("└─ Run: pip3 install psutil")
                
                # Next update countdown
                print(f"\n┌─ NEXT UPDATE IN ───────────────────────────────────────────┐")
                print(f"│ {self.interval:.1f} seconds (Press Ctrl+C to exit)")
                print("└─ Monitor PID: " + str(os.getpid()))
                
                # Sleep with CPU yield (Core2 Duo optimization)
                time.sleep(self.interval)
                    
        except KeyboardInterrupt:
            print("\n\n⏸️  Status monitor stopped gracefully.")
            update_status(self.agent_name, "Stopped", "Monitor terminated by user")
            
    def quick_check(self):
        """Quick status check without loop (for one-time queries)."""
        os.system('clear')
        
        print(f"\n┌─ {self.agent_name} QUICK STATUS ────────────────────────┐")
        print("└─ Instant Status Check (T400 Optimized)                  │")
        print("─" * 65)
        
        status = get_status() or "Idle"
        print(f"\nCurrent Agent Status:")
        print(f"  {status[:70] if len(status) > 70 else status}")
        
        if self.enable_thermal:
            print("\nThermal Status:")
            check, temp = None, None
            try:
                with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                    check = "OK" if int(f.read()) / 1000 <= 85 else "WARNING"
                    temp = int(f.read()) / 1000
            except:
                print("  ⚠️  Thermal sensor not accessible")
            else:
                print(f"  Temperature: {temp:.1f}°C [{check}]")
                
        print("\n" + "─" * 65)


# ============================================================
# COMMAND-LINE INTERFACE
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="OpenClaw Status Monitor – TUI Core")
    parser.add_argument('--agent', type=str, default=None, help="Monitor specific agent name")
    parser.add_argument('--interval', type=float, default=2.0, help="Update interval in seconds")
    parser.add_argument('--no-thermal', action='store_true', help="Disable thermal monitoring")
    parser.add_argument('--no-clear', action='store_true', help="Don't clear screen before output")
    parser.add_argument('--quick', action='store_true', help="Quick status check (single output)")
    
    args = parser.parse_args()
    
    # Initialize monitor
    monitor = StatusMonitor(
        agent_name=args.agent,
        interval=args.interval,
        enable_thermal=not args.no_thermal,
        clear_screen=not args.no_clear
    )
    
    # Run or quick check
    if args.quick:
        monitor.quick_check()
    else:
        monitor.run()


if __name__ == "__main__":
    main()
