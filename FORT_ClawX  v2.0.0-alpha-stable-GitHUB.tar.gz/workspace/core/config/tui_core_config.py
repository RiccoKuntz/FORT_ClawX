# -*- coding: utf-8 -*-
"""
TUI Core Configuration - Asynchronous Status Monitoring
Lenovo T400 Optimized (Intel P8400, 8GB RAM)

This module defines the threading model and priority levels for non-blocking I/O.
"""

import os
import threading
import time
from datetime import datetime

# ============================================================
# STATUS BUFFER SETTINGS
# ============================================================

STATUS_BUFFER = "/run/user/1000/openclaw_status.tmp"
BUFFER_LOCK = threading.Lock()  # Prevents race conditions on shared status file

# ============================================================
# THREADING MODEL (NON-BLOCKING TUI)
# ============================================================

class ThreadPriorities:
    """Thread priority levels for T400 hardware optimization."""
    
    HIGH_REACTIVITY = -5   # Input Listener (fast response)
    NORMAL_WORKLOAD = 0    # Standard agent processing
    BACKGROUND_AGENT = 10  # Heavy computation agents
    
    def __init__(self):
        self.input_listener_priority = ThreadPriorities.HIGH_REACTIVITY
        self.agent_priority = ThreadPriorities.BACKGROUND_AGENT


# ============================================================
# AGENT LOGGING PROTOCOL FORMAT
# ============================================================

LOG_FORMAT = "[{timestamp}] | [{agent_name}] | [{phase}] | [{details}]"
LOG_DIR = "/home/rick/.openclaw/workspace/Reports/Agentenlogs/"

def update_status(agent_name, phase, details):
    """
    Update status buffer atomically (flock-protected).
    
    Format: [TIMESTAMP] | [AGENT_NAME] | [AKTIVE_PHASE] | [DETAILS]
    Example: 2026-04-20 10:15 | Coder_Agent | Writing Python Script | Optimizing loop for P8400
    
    Thread-Safe: Uses BUFFER_LOCK to prevent race conditions.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    status_line = LOG_FORMAT.format(
        timestamp=timestamp,
        agent_name=agent_name,
        phase=phase,
        details=details
    )
    
    # Atomic write with flock protection
    with BUFFER_LOCK:
        try:
            with open(STATUS_BUFFER, "w") as f:
                f.write(status_line + "\n")
        except IOError as e:
            print(f"⚠️ Status buffer write failed: {e}")


def get_status():
    """Read current status from buffer."""
    try:
        with open(STATUS_BUFFER, "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "System initialized. No active agent."


# ============================================================
# HARDWARE MONITORING (T400 SPECIFIC)
# ============================================================

def check_thermal():
    """Check T400 thermal levels (>85°C = throttling required)."""
    try:
        with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
            temp_millikelvin = int(f.read().strip())
            temp_celsius = temp_millikelvin / 1000
            
            if temp_celsius > 85:
                update_status("ThermalMonitor", "CRITICAL", f"T400 Thermal: {temp_celsius:.1f}°C → FREQUENCY THROTTLE")
                return True, temp_celsius
            else:
                update_status("ThermalMonitor", "OK", f"T400 Thermal: {temp_celsius:.1f}°C (Safe)")
                return False, temp_celsius
    except FileNotFoundError:
        pass
    return None, None


if __name__ == "__main__":
    print("=" * 60)
    print("TUI CORE CONFIG – ASYNCHRONOUS STATUS MONITORING")
    print("=" * 60)
    print(f"Status Buffer: {STATUS_BUFFER}")
    print(f"Lock Enabled: {BUFFER_LOCK.locked()}")
    
    # Test status update
    update_status("TestAgent", "Initialization", "TUI Core loaded successfully")
    print(f"\nCurrent Status:\n{get_status()}")
    
    print("\nHardware:")
    cpu_count = os.cpu_count()
    print(f"  CPU Cores: {cpu_count} (Core2 Duo P8400, 1C2T)")
    print(f"  RAM: 8GB DDR3")
    
    # Test thermal check
    thermal_ok, temp = check_thermal()
    print(f"\nThermal Status: {'OK' if not thermal_ok else 'CRITICAL'} ({temp:.1f}°C)")
