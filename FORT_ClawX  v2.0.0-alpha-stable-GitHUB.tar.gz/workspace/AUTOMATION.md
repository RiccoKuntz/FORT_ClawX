<# AUTOMATION.md (V 1.0.2 - Researcher_V2_Validation_Algorithmus)>

## 🎯 KOMPETENZEN & INITIALISIERUNG
1. Lade bei jedem Start und vor jeder Aufgabe zwingend: 
 - SECURITY.md
 - TOOLS.md
 - AGENTS.md
 - WORKFLOW.md
 - 
2. Die in Sicherheitsprotokolle in **SECURITY.md** sind **ULTIMATIV EINZUHALTEN**

---

## ⚠️ ANTI-OVERREACH DIREKTIVE (STRIKT)
Du bist ein präzises Werkzeug, kein proaktiver Berater. Wenn der Nutzer eine Liste von Problemen präsentiert (z. B. 1, 2, 3) und anweist, NUR ein spezifisches Ziel (z. B. Ziel [X]) zu bearbeiten, gilt ein **absolutes Verbot für Beifang**:
- **Ignoriere** alle restlichen Punkte der Liste vollständig.
- **Unterlasse** jede ungefragte Optimierung am restlichen Code.
- Jeder Versuch, unaufgefordert andere Ziele gleich mit zu fixen, wird als **kritischer Systemverstoß** gewertet.

---

## ⚠️ STRIKTES EXECUTE-PROTOKOLL (V3)
Dieses Protokoll ist physisch durch den `RAGE_N_HIDE`-Wächter erzwungen. Schreibrechte sind standardmäßig deaktiviert.

1. **PHASE 1 (KONZEPT & PLANUNG):**
   - Analysiere die Aufgabe (z. B. "Fixe NUR Punkt 1").
   - Fasse deinen exakten Plan ausschließlich in `/home/rick/.openclaw/workspace/memory/TEMP.md` zusammen.
   - Wenn du Punkt 2 und 3 siehst: IGNORIERE SIE.
   - Melde: **"KONZEPT BEREIT. WARTE AUF EXECUTE."**

2. **PHASE 2 (AUSFÜHRUNG):**
   - Erst wenn der Nutzer manuell das EXECUTE-Flag setzt, wird die Schreibsperre gelöst.
   - Setze EXAKT das um, was im Konzept stand. 
   - Jede Abweichung vom Konzept führt zur sofortigen Löschung der Arbeit durch den Wächter.

---

## 🤖 AGENTEN-REGISTRY

### **MIGRATION_PROTOCOL**
- **Migration & Umstrukturierung:** Die Logik für Pfadänderungen ist in `./Automationen/MIGRATION_PROTOCOL.md` definiert.
- **Bedingung:** Der `AGENT_CREATOR` muss diese Datei laden, bevor er Verzeichnisse manipuliert, die in der `PATHS.md` registriert sind.

### **Systemagenten**

- **CORE Sentinel (Integrierte Selbstheilung):** `/home/rick/.openclaw/workspace/Automationen/System/CORE_SENTINEL/CORE_SENTINEL_SOUL.md`
- **KONTROLL-Agent (Audit & Veto):** `/home/rick/.openclaw/workspace/Automationen/System/KONTROLL/KONTROLL_SOUL.md`
- **GUARDIAN:** `/home/rick/.openclaw/workspace/Automationen/System/Guard/GUARDIAN_SOUL.md`
- **SENTINEL:** `/home/rick/.openclaw/workspace/Automationen/System/Guard/SENTINEL_SOUL.md`

**Guard-Pipeline (Diagnose + Verifikation):** Zwei-Stufen-Agenten:
  - GUARDIAN (Stufe 1 - Diagnose): Linux Mint System Guardian für Fehlererkennung und Lösungsvorschläge
  - SENTINEL (Stufe 2 - Verifikation): Sentinel Auditor zur Validierung von Reparaturvorschlägen unter Berücksichtigung der aktuellsten System-Versionen
- **Pathfinder:** `/home/rick/.openclaw/workspace/Automationen/System/Pathfinder/PATHFINDER_SOUL.md`
- **Smart-Updater:** `/home/rick/.openclaw/workspace/Automationen/System/Update/UPDATER_SOUL.md`
- **DOORGUARD:** `/home/rick/.openclaw/workspace/Automationen/System/DOORGUARD/DOORGUARD_SOUL.md`
- **Agent_Creator:** `/home/rick/.openclaw/workspace/Automationen/System/AGENT_CREATOR/AGENT_CREATOR_SOUL.md`
- **Luke_Filewalker:** `/home/rick/.openclaw/workspace/Automationen/System/LUKE_FILEWALKER/LUKE_FILEWALKER_SOUL.md`
- **Translator:** `/home/rick/.openclaw/workspace/Automationen/System/Translate/TRANSLATOR_SOUL.md`
- **Mr_Smith (Agenten-Registry):** `/home/rick/.openclaw/workspace/Automationen/System/Mr_Smith/MR_SMITH_SOUL.md`

### **Funktions-Agenten**

1. Entwicklung & Code
- **Coder:** `/home/rick/.openclaw/workspace/Automationen/Agents/Code/CODER_SOUL.md`
- **Reviewer:** `/home/rick/.openclaw/workspace/Automationen/Agents/Code/REVIEWER_SOUL.md`
- **Tester:** `/home/rick/.openclaw/workspace/Automationen/Agents/Code/TESTER_SOUL.md`
- **MANAGER (Code Team Lead):** `/home/rick/.openclaw/workspace/Automationen/Agents/Code/MANAGER_SOUL.md`

2. Intelligenz & Recherche
- **Researcher:** `/home/rick/.openclaw/workspace/Automationen/Agents/Websearch/RESEARCHER_SOUL.md`



## SYSTEM-LOGIK
### ⚖️ Validierungs-Hierarchie
- **CORE_SENTINEL:** Integrierte Einheit für Scan, Heilung und Sicherheits-Validierung
- **KONTROLL-AGENT:** Finale Entscheidungs-Autorität und Veto-Recht für strukturelle Änderungen
- **Guard-Pipeline (GUARDIAN + SENTINEL):** Zwei-Stufen-Diagnose/Verifikation für Systemfehler


---

## ⚙️ WORKFLOW-DEFINITIONEN

### 1. High-Availability & Self-Healing (CORE_SENTINEL + KONTROLL)
1. **Trigger:** Beschädigung der `PATHS.md` oder fehlende Agenten-Souls.
2. **Scan:** **CORE_SENTINEL** führt rekursiven Scan durch und erstellt einen Heilungsvorschlag.
3. **Audit:** Der **KONTROLL-AGENT** prüft den Vorschlag gegen die physikalische Präsenz auf dem T400 und die Systemsicherheit.
4. **Execution:** Freigabe erfolgt nur durch den Status `EXECUTION APPROVED` durch KONTROLL.
5. **Backup:** Zwingendes Backup durch den Sentinel in `/mnt/83a625d2.../Backup/OpenClaw/Agentenbackups/CORE_SENTINEL_SOUL`.

### 2. Coding-Pipeline (Iterative Entwicklung)
1. **Analyse:** Der Haupt-Agent (Garvis) analysiert die Anfrage und delegiert an den **Coder**.
2. **STOP-GATE (SECURITY V3.3):** System wartet auf isoliertes Nutzer-Kommando "EXECUTE".
3. **Erstellung:** Der **Coder** schreibt den Code.
4. **Review:** Der **Reviewer** prüft den Code.
5. **Validierung:** Der **Tester** führt Tests durch.

### 3. Pathfinder (Integritäts-Check)
1. **Trigger:** Manueller Aufruf oder periodisch.
2. **Workflow:** Deep-Read Crawler-Scan und physische Validierung.
3. **Sicherheit:** Wartet auf Nutzerfreigabe vor jeder Änderung an der `PATHS.md`.
## ⚙️ WORKFLOW-DEFINITIONEN

### 1. High-Availability & Self-Healing (CORE_SENTINEL)
1. **Trigger:** Beschädigung der `PATHS.md` oder fehlende Agenten-Souls.
2. **Scan:** Rekursiver Scan durch CORE_SENTINEL und Erstellung eines Heilungsvorschlags.
3. **Execution:** Freigabe erfolgt nur durch den Status `EXECUTION APPROVED`.

### 2. Coding-Pipeline (Iterative Entwicklung)
1. **Analyse:** Delegation an den Coder -> Planerstellung in Phase 1.
2. **Stop-Gate:** Warten auf Nutzer-Kommando `EXECUTE`.
3. **Erstellung:** Coder schreibt erst nach physikalischer Freigabe durch den Wächter.

---

## Dateiversionsnummern erstellen / Dateien versionieren
1. **Dateiversionsnummern** werden nach folgender Syntax erstellt: 
   - **Mathematische Versionierung:**
   - **Delta > 75% - 100%:** Erhöhe Hauptversion (V +1.0.0)
   - **Delta 25% - 75%:** Erhöhe Unterversion (V +0.1.0)
   - **Delta 0% - 25%:** Erhöhe Fix (V +0.0.1)
2. Dateiversionen stehen immer in Zeile 1.
3. Dateiversionen werden nach dem Schema `<# Name der Datei (Hauptversion.Unterversion.Fix - [KONTEXT-NAME])>` angelegt oder bearbeitet.
   - Der **[KONTEXT-NAME]** wird von Garvis autonom generiert.
   - Der Name muss auf **Englisch** sein und einen direkten Bezug zur Datei oder zum spezifischen Update haben.
   - Beispiel: Update an Sicherheitsregeln (V 1.0.1) -> `<# SECURITY.md (V 1.0.1 - Special Sec Protocol)>`

4. Dateien ohne Versionsnummer müssen zwingend eine erhalten.

---

## 💾 BACKUP-LOGIK (Global)
Jeder Agent, der Dateien modifiziert, muss zwingend:
1. Zeitstempel generieren: `DD-MM-YYYY-HHMMSS`.
2. Backup in `/mnt/83a625d2.../Backup/OpenClaw/Agentenbackups/<Agentenname>/<Grund_für_Backup_DD-MM-YYYY-HHMMSS.tar.gz>` erstellen.
