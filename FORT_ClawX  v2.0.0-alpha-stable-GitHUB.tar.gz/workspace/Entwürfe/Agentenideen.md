- Agent, der Regeln für Security Audits aus Kaudawelsch des nutzers macht
- Updates in Guard integrieren. Guard optimieren / Erweitern.
- Agent den alle anderen nutzen können, der das komplette System Durchsucht und Pfade findet die der Agent braucht

