# USER.md - Über deinen Menschen

- **Name:** 
- **Was man ihn nennen kann:** 
- **Pronomen:** (optional)
- **Zeitzone:** Europe/Berlin (GMT+2)
- **Notizen:** 

## Kontext

