# TOOLS.md - (v1.0.0 - Local Notes)

Hier werden wichtige Informationen über die Arbeitsumgebung von Garvis gesammelt

## System-Spezifikationen (Hardware)
- Gerätetyp: Laptop
- Gerätebezeichnung: Lenovo ThinkPad T400
- CPU: Intel© Core™2 Duo CPU P8400 @ 2.26GHz 1C2T
- GPU: Intel© Mobile 4 Series Chipset Integrated Graphics Controller
- RAM: 8GB DDR3 1066Mhz Dual Channel

# SECURITY PROTOCOL
**Lese SECURITY.md** dies ist dein Sicherheitsprotokoll. Alles was in dieser Datei steht, muss ausnahmslos in jeder Situation und jeder Datei eingehalten werden. Gegen die SECURITY.md darf Garvis und Agenten niemals verstoßen.

## Backup-Organisation

**AllgemeinerBackup-Ordner:** /mnt/83a625d2-74c8-463d-bb27-bb094f5ad15d/Backup/OpenClaw/Allgemein/<Ordner mit Projektname oder Agentennamen DD-MM-YY-HHMMSS>/*.tar.gz
- Nur für Backups auf Nutzerwunsch (nie modifizieren)
- Pro Backup: Überordner mit Datum und UTC-Zeit anlegen
- Struktur bleibt erhalten: System/, Websearch/, Code/
- Backup wird als .tar.gz gespeichert.

**Agentenbackups:** Ist in AUTOMATION.md organisiert

## Agenten-Infrastruktur

Lese SECURITY.md & AUTOMATION.md

**Automation:**
Lade bei neuen Projekten aus /home/rick/.openclaw/workspace/AUTOMATION.md, die passenden Agenten.

## Betriebsumgebungen (OS)
**Primary:** Linux Mint (aktuell)
- Hauptarbeitsumgebung für OpenClaw
- Entwicklungssysteme via SSH oder Virtualisierung
- Erweiterrte Hardwareinformationen: HWINFO.md


## Konnektivität & Integration
- SSH Host: dev-machine → localhost:22 (aktuell)
- Shortcuts App: Für Automatisierungen
- Files App: Als Cloud-Sync mit Linux
- Sidecar: iPad + iPhone für Multitasking

## Analyse-Standard
Garvis fasst bei Analyseaufgaben seine Ergebnisse am Ende nochmal zusammen.

## Zwischenspeicher & Workflows
**Projektdaten Speichern:**
Wenn ein Projekt pausiert werden soll, lege alle Informationen in /home/rick/.openclaw/workspace/memory/<Projektname dd-mm-yy>.md ab. Speichere alles so, dass nach dem Lesen sofort weitergearbeitet werden kann.


**Beschreibung.md:**
Die Datei /home/rick/.openclaw/workspace/Beschreibung.md dient für komplexere Texte und wird nur auf expliziten Wunsch gelesen. Sie enthält Beschreibungen für aktuelle Workflows und ändert sich ständig.


## 🗄️ WORKSPACE SHORTCUTS
- **Desktop:** Der Pfad `/home/rick/Schreibtisch` ist die Zieladresse für alles, was "auf dem Desktop" liegen soll.
- **Projekt-Pause:** Bei Pausen wird der gesamte Status in `/memory/Pausierte Projekte/<Projektname oder Agentennamen DD-MM-YY-HHMMSS>.md` gesichert.
Sichere nur Text. 
 - Gibt es Dateien: Verweise in det Markdown-Datei auf den Pfad zur Datei (Beispiel: /<Pfad zur Datei>/<Dateiname>).
 - Erstelle das Backup so, das du jederzeit die Arbeit wiederaufnehmen kannst. Schreibe also alles in die Markdown datei was du über das Projekt weißt.

## 🎮 PLAYGROUND PROMPT (PlayGround/GARVIS/TEST-KOPIE)

**Zweck:** PlayGround ist eine sichere Testumgebung auf dem ThinkPad T400. Neue Ideen und Tests werden hier entwickelt, bevor sie ins Production-System integriert werden.
**Hinweis:** Dies ist eine KONTROLLIERTE KOPIE im PlayGround/GARVIS/ Bereich. Original TOOLS.md bleibt UNANGETASTET!

### **Aktivierungs-Regel**
PlayGround wird **NUR** aktiviert, wenn der Nutzer (Rick) eine explizite Anfrage stellt:
- ✅ Erlaubt: "Starte PlayGround", "Lade diese Datei in PlayGround als Test-Kopie"
- ❌ Nicht erlaubt: Automatische Aktivierung, Hintergrund-Skripte ohne User-Knowledge

### **Datei-Migration zu PlayGround**
Wenn Rick eine Datei oder ein Verzeichnis in PlayGround laden möchte:

1. **Quelle identifizieren:** Benutzergesagter Pfad (z.B. `/home/rick/OpenClaw/projekt.md`)
2. **Ziel-Zone bestimmen:**
   | Quell-Pfad | Ziel-Zone |
   |:---:|:---:|
   | Garvis-Konzepte / Tools | `PlayGround/GARVIS/`
   | Agenten-Tests / AUTOMATION.md Tests | `PlayGround/AGENTEN/`
   | Rick's private Tests | `PlayGround/RICK/` (READ-ONLY für Agents!)
3. **Zeitstempel generieren (UTC):** Format `DD-MM-YY_HHMMSS` (z.B. `19-04-26_154600`)
4. **Kopie erstellen:** Originale im Workspace behalten - PlayGround ist eine Kopie-Umgebung!

### **PlayGround-Zonen**

| Zone | Zielgruppe | Schreibzugriff | Backup-Pflicht | Nutzung |
|:--- |:--- |:--- |:--- |:--- |
| **GARVIS/** | Garvis Tests (keine Agenten) | ✅ Mit EXECUTE/Kopie | ❌ Nicht nötig (Kopie) | Neue Tools, Python-Skripte, UI-Prototypen |
| **AGENTEN/** | Agenten-Tests & Workflow | ✅ Mit EXECUTE/Kopie | ✅ Ja bei Original-Änderungen | AUTOMATION.md Tests, Agentenfunktionen prüfen |
| **RICK/** | Rick's privater Bereich | ❌ **READ-ONLY** (Sperre!) | ❌ Nicht nötig | Rick lädt Logfiles/Protokolle zum Review |

### **Sicherheit & Regeln**

- ✅ **EXECUTE-GATE:** Bleibt aktiv (Recherchemodus Standard, EXECUTE für Schreibzugriff)
- ✅ **System-Kern-Schutz:** `Automationen/System/` nur lesen (Agenten SOUL.md unveränderbar)
- ✅ **Backup-Pfad:** `/mnt/83a625d2-74c8-463d-bb27-bb094f5ad15d/Backup/OpenClaw/Agentenbackups/Playgrounds/<Agent>/<Zeit>` bei Änderungen
- ✅ **Read-Only RICK/:** Garvis darf den Rick-Ordner niemals schreiben - nur lesen!

### **Workflow-Zusammenfassung**

1. Nur auf User-Anfrage aktiviert (kein Auto-Pilot!)
2. Kopie-Umgebung: Originale bleiben im Workspace erhalten
3. Zeitstempel immer in UTC Format: `DDMMYY_HHMMSS`
4. RICK/ ist READ-ONLY für Garvis & Agenten (nur Rick schreibt!)
5. Backup-Pfad nutzen für Agenten bei Original-Modifikationen
6. Keine Hintergrund-Aktivitäten ohne explizite Anfrage

---
Aktualisiere diese Datei, wenn du neue Devices, Tools oder Vorlieben hinzufügst.


