#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test Script – Async Status Monitoring Validation

Validates the TUI core components before full deployment.
T400 Optimized: Verifies non-blocking I/O on Core2 Duo hardware.

Usage:
  python3 /home/rick/.openclaw/workspace/core/config/test_async_status.py
"""

import os
import sys
import time
from tui_core_config import (
    STATUS_BUFFER, 
    update_status, 
    get_status,
    check_thermal,
    ThreadPriorities
)


def print_header(title):
    """Print formatted section header."""
    print("\n" + "─" * 60)
    print(f" {title}")
    print("─" * 60 + "\n")


def test_status_buffer():
    """Test status buffer read/write operations."""
    print_header("[TEST 1] STATUS BUFFER VALIDATION")
    
    # Write test data
    update_status("StatusBufferTest", "Write Test", "Testing atomic write operation")
    time.sleep(0.1)
    
    # Read back
    try:
        with open(STATUS_BUFFER, "r") as f:
            content = f.read()
            
        print(f"✓ Write successful → Buffer has content ({len(content)} bytes)")
        print(f"  Content preview:")
        for line in content.split('\n')[-3:]:
            if line.strip():
                print(f"    {line}")
                
        return True
        
    except Exception as e:
        print(f"✗ Read failed: {e}")
        return False


def test_thread_safety():
    """Test concurrent writes to status buffer."""
    print_header("[TEST 2] THREAD SAFETY (flock protection)")
    
    import threading
    
    success_count = 0
    
    def writer_agent(agent_name, thread_id):
        """Thread-safe write simulation."""
        for i in range(5):
            update_status(agent_name, f"Thread {thread_id}", f"Concurrent write #{i}")
            time.sleep(0.05)  # Simulate work
            
    # Create threads
    writers = []
    for i in range(3):
        t = threading.Thread(target=writer_agent, args=(f"Agent_{i}", i))
        writers.append(t)
        
    # Start all (concurrent writes)
    for t in writers:
        t.start()
        
    # Wait completion
    for t in writers:
        t.join()
    
    # Verify buffer state
    try:
        with open(STATUS_BUFFER, "r") as f:
            lines = f.readlines()
            
        print(f"✓ All {len(lines)} writes captured atomically")
        success_count += 1
        
    except Exception as e:
        print(f"✗ Buffer integrity failed: {e}")
    
    return success_count == 3


def test_thermal_monitor():
    """Test thermal reading for T400."""
    print_header("[TEST 3] THERMAL MONITOR (T400 Hardware)")
    
    try:
        with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
            temp = int(f.read()) / 1000
            
        status, display_temp, _ = check_thermal()
        
        print(f"✓ Thermal read successful: {display_temp:.1f}°C [{status}]")
        
        # Test throttle logic
        if status == "WARNING":
            print("⚠️  WARNING level reached – Throttle will engage")
            
    except FileNotFoundError:
        print("⚠️  Thermal sensor not found (check /sys/class/thermal/)")
        
    return True


def test_priority_levels():
    """Verify process priority settings."""
    print_header("[TEST 4] PROCESS PRIORITY VERIFICATION")
    
    import os
    
    try:
        current_nice = os.nice()
        print(f"✓ Current nice level: {current_nice}")
        
        # Try to set high reactivity
        if hasattr(os, 'nice'):
            try:
                os.nice(ThreadPriorities.HIGH_REACTIVITY)
                new_nice = os.nice()
                print(f"✓ Set Input Listener priority: nice={ThreadPriorities.HIGH_REACTIVITY}")
            except PermissionError:
                print("⚠️  Need root/sudo for priority change")
                
    except Exception as e:
        print(f"✗ Priority test failed: {e}")
        
    return True


def test_hardware_context():
    """Verify T400 hardware constraints are understood."""
    print_header("[TEST 5] HARDWARE CONTEXT (T400 SPECIFICATIONS)")
    
    import os
    
    cpu_count = os.cpu_count()
    mem_gb = 8  # Known from TOOLS.md
    
    print(f"✓ CPU Cores: {cpu_count} (Core2 Duo P8400, 1C2T)")
    print(f"✓ RAM: {mem_gb}GB DDR3 1066MHz Dual Channel")
    print("✓ Non-blocking I/O designed for this hardware")
    
    return True


def main():
    """Run all validation tests."""
    
    print_header("=" * 60)
    print("ASYNC STATUS MONITORING – TEST SUITE")
    print("Hardware: Lenovo T400 (Intel Core2 Duo P8400, 8GB RAM)")
    print("=" * 60 + "\n")
    
    tests = [
        test_status_buffer(),
        test_thread_safety(),
        test_thermal_monitor(),
        test_priority_levels(),
        test_hardware_context()
    ]
    
    # Results summary
    print("\n" + "─" * 60)
    print("TEST SUMMARY")
    print("─" * 60)
    
    if all(tests):
        print("✅ ALL TESTS PASSED – System ready for async status monitoring")
        
        # Quick demo output
        print("\n┌─ QUICK STATUS DEMO ───────────────────────────────────────┐")
        print(f"│ Active Agent: Status buffer functional ✓                   │")
        print(f"│ Thermal Monitor: {check_thermal()[0]}")
        print("└─ Test Suite Completed Successfully")
        
    else:
        print("⚠️  Some tests failed – Review warnings above")
        
    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
