# 🗺️ OpenClaw Central Path Registry

Diese Datei definiert die physische Struktur des Workspaces. Alle Agenten laden diese Pfade bei der Initialisierung, um autonom navigieren zu können.

---

## 🏗️ Kern-Verzeichnisse (Core)

| Pfad | Funktion |
|:--- |:--- |
| `/home/rick/.openclaw/workspace/` | **Root-Verzeichnis:** Basis für alle relativen Pfade und Konfigurationsdateien. |
| `/home/rick/.openclaw/workspace/memory/` | **Langzeitgedächtnis:** Speicherort für `TEMP.md` und projektübergreifende Daten. |
| `/home/rick/.openclaw/workspace/avatars/` | **Identität:** Enthält visuelle Assets für Garvis (`garvis.png`). |
| `/run/user/1000/openclaw_status.tmp` | **RAM-Disk Status-Buffer:** Hochfrequenter Status-Tempfile (Non-blocking I/O). |

## 🔄 Core Workspace Subdirectories

| Pfad | Funktion |
|:--- |:--- |
| `/home/rick/.openclaw/workspace/core/` | **TUI-CORE:** Asynchroner Status-Monitoring & Agent-Orchestration. |
| `/home/rick/.openclaw/workspace/core/config/` | **Konfiguration:** Agent-Souls, PATHS.md, Automation-Registry. |
| `/home/rick/.openclaw/workspace/core/output/` | **Ausgabe:** TUI-Ausgaben & Status-Logs (Buffered). |

---

## 🤖 Automatisierung & Logik

| Pfad | Funktion |
|:--- |:--- |
| `/home/rick/.openclaw/workspace/Automationen/` | **Workflow-Hub:** Hauptordner für alle Agenten-Souls und Prozessbeschreibungen. |
| `/home/rick/.openclaw/workspace/Automationen/System/` | **SysAdmin-Zentrale:** Beherbergt Guards (Linux/OpenClaw) und den Updater. |
| `/home/rick/.openclaw/workspace/Backup Temp/` | **Sicherheits-Layer:** Zwischenspeicher für autonome Backups vor Systemänderungen. |
| `/home/rick/.openclaw/workspace/skills/` | **Werkzeugkasten:** Enthält Python-Skripte und Tools (Websearch, Filesystem etc.). |

---

## 📂 Arbeitsbereiche (Workspace Operations)

| Pfad | Funktion |
|:--- |:--- |
| `/home/rick/.openclaw/workspace/Arbeitsordner/Input/` | **Eingang:** Hier legst du Dateien ab, die die Agenten verarbeiten sollen (Read-Only). |
| `/home/rick/.openclaw/workspace/Arbeitsordner/Work/` | **Baustelle:** Aktive Bearbeitung von Projekten durch Agenten (Read/Write). |
| `/home/rick/.openclaw/workspace/Arbeitsordner/Output/` | **Ergebnis:** Ablageort für finalisierte und durch Tester geprüfte Projekte. |

---

## 📊 Monitoring & Reporting

| Pfad | Funktion |
|:--- |:--- |
| `/home/rick/.openclaw/workspace/Reports/` | **Zentrales Reporting:** Basisordner für alle Logs und Analysen. |
| `/home/rick/.openclaw/workspace/Reports/Projektlogs/` | **Fehleranalyse:** Explizite Log-Dateien für Debugging und Projekthistorie. |
| `/home/rick/.openclaw/workspace/Reports/Agentenlogs/` | **Transparenz:** Protokolle über autonome Handlungen der Guards. |

# OPERATIVE PFADE (VON RAGE_N_HIDE ÜBERWACHT)
DIR_SYSTEM_AGENTS: "/home/rick/.openclaw/workspace/Automationen/System/"
DIR_REGULAR_AGENTS: "/home/rick/.openclaw/workspace/Automationen/Agents/"

---

## 💾 Externe Speichermedien (Storage)

| Pfad | Funktion |
|:--- |:--- |
| `/mnt/83a625d2-74c8-463d-bb27-bb094f5ad15d/Backup/OpenClaw/Agentenbackups/` | **Archiv:** Externes Datengrab auf der 2 TB Seagate HDD für permanente Sicherungen. |
| `/home/rick/Schreibtisch/` | **Desktop Shortcut:** Referenzpunkt für schnelle Dateiablage ("auf dem Desktop"). |

---

## 🔗 Referenzen
- **Agenten-Souls:** Die spezifischen `.md`-Pfade der Agenten sind in der `AUTOMATION.md` unter `## AGENTENPFADE` hinterlegt.
- **Sicherheits-Ausnahmen:** Pfadspezifische Erlaubnisse (z.B. für den Updater) sind in der `SECURITY.md` definiert.

**Autonomie-Hinweis:**
Sollte diese Datei beschädigt werden, nutzt der **OpenClaw Guardian** diese Struktur-Vorgabe, um die Verzeichnisse durch einen Tiefenscan ab `/home/rick/.openclaw/workspace/` wiederherzustellen.
