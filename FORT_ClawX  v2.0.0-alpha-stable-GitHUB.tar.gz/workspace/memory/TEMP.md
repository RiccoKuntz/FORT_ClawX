# TEMP - AUTOMATION.md Update: Guard-Pipeline Individualisierung

## KONZEPT BEREIT. WARTE AUF EXECUTE.

### Ziel
Individuelle Registrierung von GUARDIAN und SENTINEL in AUTOMATION.md statt kollektiver "Guard-Pipeline" Eintragung.

### Änderungen an AUTOMATION.md (System-Agenten Abschnitt)

**Aktuell:**
```markdown
- **Guard-Pipeline (Diagnose + Verifikation):** `/home/rick/.openclaw/workspace/Automationen/System/Guard/` - Zwei-Stufen-Agenten:
  - **GUARDIAN (Stufe 1 - Diagnose):** Linux Mint System Guardian für Fehlererkennung und Lösungsvorschläge
  - **SENTINEL (Stufe 2 - Verifikation):** Sentinel Auditor zur Validierung von Reparaturvorschlägen unter Berücksichtigung der aktuellsten System-Versionen
```

**Neu:**
```markdown
- **GUARDIAN:** `/home/rick/.openclaw/workspace/Automationen/System/Guard/GUARDIAN_SOUL.md`
- **SENTINEL:** `/home/rick/.openclaw/workspace/Automationen/System/Guard/SENTINEL_SOUL.md`

**Guard-Pipeline (Diagnose + Verifikation):** Zwei-Stufen-Agenten:
  - GUARDIAN (Stufe 1 - Diagnose): Linux Mint System Guardian für Fehlererkennung und Lösungsvorschläge
  - SENTINEL (Stufe 2 - Verifikation): Sentinel Auditor zur Validierung von Reparaturvorschlägen unter Berücksichtigung der aktuellsten System-Versionen
```

### Workflow
1. GUARDIAN findet Problem → erstellt Vorschlag
2. GUARDIAN delegiert an SENTINEL mit aktuellen System-Daten ($DISTRO, $KERNEL)
3. SENTINEL validiert Vorschlag (5-Quellen-Check)
4. SENTINEL gibt finale Entscheidung: EXECUTION APPROVED oder ABORT

### Sicherheit
- Pipeline-Arbeitsweise bleibt intakt
- GUARDIAN delegiert weiterhin an SENTINEL (kein direkter User-Zugriff)
- SENTINEL übernimmt Daten vom Guardian (keine eigenständige Diagnose)
