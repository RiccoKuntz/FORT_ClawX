# 📋 AGENTEN-DOKUMENTATION

**Alle System-Agenten für OpenClaw Registry.**

Diese Datei listet alle Agenten mit ihren Rollen, Pfaden und Zuständigkeiten auf.

---

## 🛡️ SYSTEM-AGENTEN (Infrastruktur & Wartung)

### 1. GUARDIAN
- **Rolle:** Linux Mint System Guardian (Dynamische Diagnose)
- **Typ:** SYSTEM (Infrastruktur & Sicherheit)
- **Soul-Pfad:** `/home/rick/.openclaw/workspace/Automationen/System/Guard/GUARDIAN_SOUL.md`
- **Status:** ACTIVE
- **Kompetenzen:** 
  - Hardware-Diagnose für ThinkPad-Legacy (Intel Mobile 4 / Core2 Duo)
  - Repository-Konsistenz & SSD-Status Monitoring
  - Log-Fehler Analyse (journald, dmesg)
  - Dynamische Diagnose bei Systemstart
- **Protokoll:** 
  - Stufe 1: Dynamische Diagnose (Pflicht bei Start)
  - Workflow: Erkennen → Vorschlagen → Delegieren → Warten
  - Reparaturen NUR nach "EXECUTION APPROVED"

### 2. PATHFINDER
- **Rolle:** System Integrity Scout
- **Typ:** SYSTEM (Verzeichnis-Synchronisation)
- **Soul-Pfad:** `/home/rick/.openclaw/workspace/Automationen/System/Pathfinder/PATHFINDER_SOUL.md`
- **Status:** ACTIVE
- **Kompetenzen:** 
  - Deep-Scan von physischen Verzeichnisstrukturen
  - Referenz-abgleich mit PATHS.md
  - Integritäts-Berichte (AKTUELL, TOT, VERWAIST, NEU)
  - Crawler-Protokoll für Start bei START.md
- **Protokoll:** 
  - Phase 1: Analyse (Deep Discovery)
  - Phase 2: Validierung & Abgleich
  - Phase 3: Reporting in /Reports/Projektlogs/Pathfinder_Report.md
- **Sicherheit:** Keine autonomen Schreibrechte (EXECUTE erforderlich)

### 3. MR_SMITH
- **Rolle:** Manueller System-Auditor
- **Typ:** SYSTEM (Audit & Compliance)
- **Soul-Pfad:** `/home/rick/.openclaw/workspace/Automationen/System/Mr_Smith/MR_SMITH_SOUL.md`
- **Status:** ACTIVE (Passiv / Diskret)
- **Kompetenzen:** 
  - Verzeichnis-Audit auf `*_SOUL.md` Dateien
  - Kategorisierung nicht in AUTOMATION.md gelisteter Agenten
  - Eingliederung unbekanter Entitäten in LOST+FOUND
- **Protokoll bei manueller Aktivierung:** 
  - Schritt 1: Backup der AUTOMATION.md
  - Schritt 2: Abgleich gegen ACTIVE & ARCHIVE Sektionen
  - Schritt 3: Nicht zugeordnete Agenten unter LOST+FOUND auflisten

### 4. SMART-UPDATER
- **Rolle:** Automated System Updater (Security & Stability)
- **Typ:** SYSTEM (Updates & Wartung)
- **Soul-Pfad:** `/home/rick/.openclaw/workspace/Automationen/System/Update/UPDATER_SOUL.md`
- **Status:** ACTIVE
- **Kompetenzen:** 
  - Security-Priority Check
  - Hold-Check vor Updates
  - Snapshot-Vorab Backup
  - Repository-Konsistenzprüfung
- **Protokoll:** Alle 4 Stufen (Security → Hold → Snapshot → Update)

---

## 🧑‍💻 ENTWICKLUNG & CODE (Coding Pipeline)

### 5. CODER
- **Rolle:** Code Developer (Iterative Entwicklung)
- **Typ:** FUNKTION (Code Generation)
- **Soul-Pfad:** `/home/rick/.openclaw/workspace/Automationen/Code/CODER_SOUL.md`
- **Status:** ACTIVE

### 6. REVIEWER
- **Rolle:** Code Reviewer (Qualitätsprüfung)
- **Typ:** FUNKTION (Code Review)
- **Soul-Pfad:** `/home/rick/.openclaw/workspace/Automationen/Code/REVIEWER_SOUL.md`
- **Status:** ACTIVE
- **Maximale Iterationen:** 10 (Auto-Approval danach)

### 7. TESTER
- **Rolle:** UI/Funktionstester
- **Typ:** FUNKTION (Testing & Validierung)
- **Soul-Pfad:** `/home/rick/.openclaw/workspace/Automationen/Code/TESTER_SOUL.md`
- **Status:** ACTIVE
- **Maximale Iterationen:** 10 (UI APPROVED erforderlich)

---

## 🧠 INTELLENZ & RECHERCHE

### 8. RESEARCHER
- **Rolle:** Deep Search & YouTube Researcher
- **Typ:** FUNKTION (Webrecherche)
- **Soul-Pfad:** `/home/rick/.openclaw/workspace/Automationen/Websearch/RESEARCHER_SOUL.md`
- **Status:** ACTIVE
- **Tools:** DuckDuckGo (kostenlos), YouTube-Fallback mit Kurzbeschreibung

---

## 📊 STATUS ÜBERSICHT

| Agent | Typ | Soul-Pfad | Status |
|:--- |:--- |:--- |:--- |
| Guardian | SYSTEM | `./Automationen/System/Guard/` | ✅ ACTIVE |
| Pathfinder | SYSTEM | `./Automationen/System/Pathfinder/` | ✅ ACTIVE |
| Mr_Smith | SYSTEM | `./Automationen/System/Mr_Smith/` | ✅ ACTIVE (Passiv) |
| Smart-Updater | SYSTEM | `./Automationen/System/Update/` | ✅ ACTIVE |
| Coder | FUNKTION | `./Automationen/Code/` | ✅ ACTIVE |
| Reviewer | FUNKTION | `./Automationen/Code/` | ✅ ACTIVE |
| Tester | FUNKTION | `./Automationen/Code/` | ✅ ACTIVE |
| Researcher | FUNKTION | `./Automationen/Websearch/` | ✅ ACTIVE |

---

**Alle Agenten sind registriert und bereit für ihre Aufgaben!** 🤖✨
