# -*- coding: utf-8 -*-
"""
Input Listener Thread – Non-Blocking TUI Interaction Handler

This module provides the dedicated InputListener thread that monitors user input
(?, status, stop) without blocking the main agent processing loop.

T400 Optimized: Uses nice -n -5 for high reactivity on Core2 Duo CPU.
"""

import os
import sys
import threading
import subprocess
import tty
import termios
import select
from datetime import datetime
from tui_core_config import (
    STATUS_BUFFER, 
    BUFFER_LOCK, 
    update_status, 
    get_status,
    check_thermal
)

# ============================================================
# TERMINAL INPUT HANDLER
# ============================================================

class InputListener(threading.Thread):
    """
    Non-blocking input listener for TUI interactions.
    
    Handles commands:
    - '?' : Show current agent status from buffer
    - 'status' : Same as '?' (verbose mode)
    - 'stop' : Terminate active agent process
    
    Thread Safety: Uses BUFFER_LOCK for atomic reads/writes.
    """
    
    def __init__(self, agent_process=None):
        super().__init__(daemon=True)
        self.running = True
        self.agent_process = agent_process  # Optional subprocess to terminate
        
        print("=" * 60)
        print("TUI INPUT LISTENER THREAD STARTED")
        print(f"PID: {os.getpid()} | Priority: nice -n -5")
        print(f"Buffer Path: {STATUS_BUFFER}")
        print("=" * 60)
        
    def run(self):
        """Main input loop – Non-blocking terminal read."""
        while self.running:
            try:
                # Check thermal before every cycle (T400 safety)
                thermal_ok, temp = check_thermal()
                
                # Clear terminal screen for clean status display
                print("\n" + "─" * 60)
                
                # Show current agent status from buffer
                if self.agent_process:
                    status_text = f"[Agent Process PID={self.agent_process.pid}] " if self.agent_process.pid else ""
                    current_status = get_status()
                    
                    print(f"┌─ TUI STATUS BUFFER ───────────────────────────────────────┐")
                    print(f"│ Current Status: {current_status or 'Idle'}")
                    print(f"│ Status Buffer File: {STATUS_BUFFER}")
                    print(f"└─ Hardware Monitor ────────────────────────────────────────┘")
                    print(f"  CPU Temp: {temp:.1f}°C {'⚠️ OVERHEATING!' if not thermal_ok else '✓ Safe'}")
                    print("─" * 60)
                    
                # Check for input (non-blocking via select)
                stdin_fd = sys.stdin.fileno()
                
                try:
                    ready_fds, _, _ = select.select([sys.stdin], [], [], 1.0)  # 1s timeout
                    
                    if ready_fds:
                        fd_set = set()
                        fd_set.add(stdin_fd)
                        
                        original_settings = tty.tcgetattr(sys.stdin.fileno())
                        tty.setraw(sys.stdin.fileno())
                        
                        chunk = sys.stdin.read(1)
                        
                        tty.setcbreak(sys.stdin.fileno())
                        tty.setattrs(sys.stdin.fileno(), original_settings)
                        
                        if chunk:
                            self.handle_input(chunk)
                            
                except (OSError, select.error) as e:
                    # Ignore non-critical input errors
                    pass
                    
            except KeyboardInterrupt:
                print("\n⏸️ Listener paused. Press Ctrl+C again to exit.")
            except Exception as e:
                print(f"❌ Input listener error: {e}")
                
    def handle_input(self, key):
        """Handle single key input with command parsing."""
        if key == '?':
            self.show_status()
            
        elif key.lower() in ['status', 's']:
            self.show_verbose_status()
            
        elif key.lower() in ['stop', 'q', '\n']:
            self.stop_agent()
            
        else:
            print(f"  ← Press '?' for status | 'stop' to terminate →")
            
    def show_status(self):
        """Display current agent status from buffer."""
        try:
            with open(STATUS_BUFFER, "r") as f:
                lines = f.readlines()
                
            if lines:
                print("\n" + "─" * 60)
                print("CURRENT AGENT STATUS:")
                for line in lines[-5:]:  # Show last 5 status updates
                    print(f"  {line.strip()}")
                print("─" * 60)
            else:
                print("\nNo active agent. System is idle.")
                
        except Exception as e:
            print(f"Status read failed: {e}")
            
    def show_verbose_status(self):
        """Verbose status with process tree and thermal info."""
        print("\n" + "─" * 60)
        print("TUI STATUS VERBOSE OUTPUT")
        print("─" * 60)
        
        # Agent process info
        if self.agent_process:
            print(f"\nAgent Process:")
            print(f"  PID: {self.agent_process.pid}")
            print(f"  Status: {'Running' if self.agent_process.poll() is None else 'Terminated'}")
            
        # Buffer contents
        status_lines = get_status().split('\n') if get_status() else []
        for line in status_lines[-3:]:
            if line.strip():
                print(f"  {line}")
                
        # Thermal info
        thermal_ok, temp = check_thermal()
        print(f"\nHardware Monitor:")
        print(f"  CPU Temp: {temp:.1f}°C {'⚠️ OVERHEATING!' if not thermal_ok else '✓ Safe'}")
        print("─" * 60)
        
    def stop_agent(self):
        """Terminate active agent process with SIGTERM."""
        if self.agent_process:
            try:
                print(f"\n⏸️ Sending SIGTERM to Agent Process {self.agent_process.pid}...")
                self.agent_process.terminate()
                
                # Wait for graceful shutdown (max 5s)
                try:
                    self.agent_process.wait(timeout=5)
                    print("✓ Agent process terminated gracefully.")
                except subprocess.TimeoutExpired:
                    print("⏸️ Process didn't exit, force killing...")
                    self.agent_process.kill()
                    
            except Exception as e:
                print(f"Agent termination failed: {e}")
            
        print("\n⏸️ INPUT LISTENER STOPPED. System ready for new agent.")
        sys.exit(0)


# ============================================================
# START SCRIPT
# ============================================================

def start_input_listener(agent_process=None):
    """
    Launch Input Listener thread with process priority adjustment.
    
    Usage: input_listener = start_input_listener(your_agent_process)
    """
    
    # Set nice priority (High reactivity on T400 Core2 Duo)
    os.nice(ThreadPriorities.HIGH_REACTIVITY if hasattr(os, 'nice') else 0)
    
    listener = InputListener(agent_process=agent_process)
    listener.start()
    
    return listener


if __name__ == "__main__":
    print("=" * 60)
    print("INPUT LISTENER – NON-BLOCKING TUI INTERFACE")
    print("=" * 60)
    print("\nAvailable Commands:")
    print("  ?        → Show current status")
    print("  status   → Verbose status output")
    print("  stop     → Terminate agent process & exit")
    print("=" * 60)
    print("\nStarting Input Listener thread...")
    
    listener = start_input_listener()
    
    try:
        while True:
            # Yield to OS scheduler (keep thread responsive)
            threading.Thread._Thread__stop_join_thread_safe = True
            threading.Event().wait(1.0)  # Sleep for 1s
                
    except KeyboardInterrupt:
        print("\nGoodbye!")
