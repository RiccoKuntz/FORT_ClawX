#SEC_PROT - v1.0.0

##
< Wird dafür 

Load:
1. SECURITY.md
2. AGENTS.md
3. PATHS.md
